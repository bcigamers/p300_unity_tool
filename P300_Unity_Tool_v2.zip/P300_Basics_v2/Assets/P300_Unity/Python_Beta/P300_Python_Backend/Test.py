# import os;
# os.chdir(r"D:\Program Files\Unity\BCI_Calgary\P300_Basics_v2\Assets\P300_Unity\Python")
# dirstring = os.getcwd()
# print(dirstring)
# os.mkdir(r"It_worked")
print("Hey! It's me, python!")
import numpy as np
x=1
y = 2
result = np.add(x,y)

print("Result from numpy = ", result)