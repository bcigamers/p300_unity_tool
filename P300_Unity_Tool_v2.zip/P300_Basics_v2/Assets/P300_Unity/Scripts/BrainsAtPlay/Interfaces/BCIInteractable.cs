public interface IBCIInteractable
{
    void ReactToBCI();
    void SendEventToWeb();
}
