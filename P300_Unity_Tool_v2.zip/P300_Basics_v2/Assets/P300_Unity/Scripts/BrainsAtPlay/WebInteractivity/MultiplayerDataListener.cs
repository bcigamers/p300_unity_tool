using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class MultiplayerDataListener : MonoBehaviour
{
    // Implement this in a similar way to the BCI data listener to receive data about multiplayer objects
    // We do not know what kinds of multiplayer data might be there though.
}
